(() => {
  const cv = document.createElement("canvas");
  document.body.appendChild(cv);
  const ctx = cv.getContext("2d");
  let stars = [], shoot = null, W = 0, H = 0;
  function resize() {
    W = cv.width = window.innerWidth;
    H = cv.height = window.innerHeight;
    const n = Math.min(260, Math.round(W * H / 7000));
    stars = Array.from({ length: n }, () => ({
      x: Math.random() * W, y: Math.random() * H,
      r: Math.random() * 1.4 + 0.3, p: Math.random() * Math.PI * 2,
      s: 0.4 + Math.random() * 1.2,
    }));
  }
  window.addEventListener("resize", resize);
  resize();
  // 轻量桌面协议：就绪后索取一次窗口信息
  try { parent.postMessage({ type: "WALLPAPER_READY" }, "*"); } catch (e) {}
  window.addEventListener("message", (ev) => {
    if (ev.data && ev.data.type === "DESKTOP_INFO") console.log("desktop says", ev.data.data);
  });
  function tick(t) {
    ctx.clearRect(0, 0, W, H);
    for (const st of stars) {
      const a = 0.35 + 0.65 * Math.abs(Math.sin(st.p + t / 900 * st.s));
      ctx.globalAlpha = a;
      ctx.fillStyle = "#dfe8ff";
      ctx.beginPath(); ctx.arc(st.x, st.y, st.r, 0, 7); ctx.fill();
    }
    if (!shoot && Math.random() < 0.006) {
      shoot = { x: Math.random() * W * 0.7, y: Math.random() * H * 0.3, v: 7 + Math.random() * 5, life: 40 };
    }
    if (shoot) {
      ctx.globalAlpha = Math.max(0, shoot.life / 40);
      ctx.strokeStyle = "#9fd0ff"; ctx.lineWidth = 1.6;
      ctx.beginPath(); ctx.moveTo(shoot.x, shoot.y); ctx.lineTo(shoot.x - 46, shoot.y - 18); ctx.stroke();
      shoot.x += shoot.v; shoot.y += shoot.v * 0.4; shoot.life--;
      if (shoot.life <= 0 || shoot.x > W + 60) shoot = null;
    }
    ctx.globalAlpha = 1;
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
})();
